/** 
 * Simple program to illustrate the use of structures
 */

#include<iostream>
#include <string>


using namespace std;


/* Creating the structure Student */
struct Student
{
 string name;
 string state;
 int age;
};

void printStudentInfo(Student &S)
{
    cout<<S.name<<" From "<<S.state<<" ( "<<S.age<<" )"<<endl;
}



int main()
{
    Student S;
    S.name = "Adil";
    S.state = "Fes";
    S.age = 23;
    printStudentInfo(S);


    //initialisation uniforme
    Student S2{"Hicham", "Fes", 25};
    printStudentInfo(S2);


    //( Deep vs Shallow copy)
    Student S3 = S2;
    S3.name = "New";
    printStudentInfo(S3);

    printStudentInfo(S2);
}

