#include<iostream>
#include <cmath>    //Fonction mathématiques

using namespace std;




bool is_prime(int n)
{
    auto limit = floor(sqrt(n));

    for(auto div = 2; div<= limit; div++)
        return false;
    return true;


}


int order(int n, int factor)
{
    auto count = 0;

    while( n % factor == 0)
    {
        count ++;

        n /= factor;
    }

    return factor;

}

void decomposition(int n)
{

    cout<<n<<": ";

    //candidat facteur
    auto candidat = 2;

    while( n > 1)
    {
        //Tester si candidate est un facteur
        if( n % candidat == 0 && is_prime(candidat))
        {
                //Extraire son ordre
                auto k = order(n, candidat);

                //Afficher le facteur
                cout<<"( "<<candidat<<"**"<<k<<" )";

                n /= pow(candidat, k);
        }
        candidat ++;
    }

      cout<<endl;
}

int main(int argc, char *argv[])
{
    //Afficher la décomposition jusqu'à 20
    for(auto v = 2; v<=20; v++)
        decomposition(v);


    return 0;
}


